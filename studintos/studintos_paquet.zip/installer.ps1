$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$src = Split-Path -Parent $MyInvocation.MyCommand.Path
$dest = Join-Path $src 'Studintos'
$exe = Join-Path $dest 'Studintos.exe'
$tmp = Join-Path $env:TEMP 'studintos_install'
New-Item -ItemType Directory -Force -Path $tmp | Out-Null
if (-not (Test-Path $exe)) {
  $voisins = @('..\AliceCalculatrice-installateur\AliceCalculatrice', '..\AliceTelecharge-installateur\AliceTelecharge', '..\AliceMontage-installateur\AliceMontage')
  $trouve = $null
  foreach ($v in $voisins) { $p = Join-Path $src $v; if (Test-Path (Join-Path $p 'resources')) { $trouve = $p; break } }
  if ($trouve) {
    Write-Host '1/2 Moteur Electron deja present avec une autre application Alice : copie locale...'
    New-Item -ItemType Directory -Force -Path $dest | Out-Null
    Get-ChildItem -Path $trouve -Force | Where-Object { $_.Name -ne 'resources' } | ForEach-Object { Copy-Item -Recurse -Force $_.FullName $dest }
    $res = Join-Path $dest 'resources'; New-Item -ItemType Directory -Force -Path $res | Out-Null
    Get-ChildItem -Path (Join-Path $trouve 'resources') -Force | Where-Object { $_.Name -notin @('app', 'bin') } | ForEach-Object { Copy-Item -Recurse -Force $_.FullName $res }
    $autre = Get-ChildItem -Path $dest -Filter 'Alice *.exe' | Select-Object -First 1
    if ($autre) { Rename-Item $autre.FullName 'Studintos.exe' }
  } else {
    Write-Host '1/2 Telechargement du moteur (Electron, environ 110 Mo)...'
    $ez = Join-Path $tmp 'electron.zip'
    Invoke-WebRequest -UseBasicParsing -Uri 'https://github.com/electron/electron/releases/download/v31.7.7/electron-v31.7.7-win32-x64.zip' -OutFile $ez
    if ((Get-Item $ez).Length -lt 100MB) { throw 'Telechargement Electron incomplet' }
    Expand-Archive -Force -Path $ez -DestinationPath $dest
    Rename-Item (Join-Path $dest 'electron.exe') 'Studintos.exe'
  }
  Remove-Item -Force -ErrorAction SilentlyContinue (Join-Path $dest 'resources\default_app.asar')
}
if (-not (Test-Path $exe)) { throw 'Studintos.exe introuvable apres la copie' }
Write-Host '2/2 Installation des fichiers du programme...'
$app = Join-Path $dest 'resources\app'
if (Test-Path $app) { Remove-Item -Recurse -Force $app }
Copy-Item -Recurse -Force (Join-Path $src 'app') $app
Write-Host 'Termine. Lancement...'
Start-Process $exe
Remove-Item -Recurse -Force -ErrorAction SilentlyContinue $tmp
